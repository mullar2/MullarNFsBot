   ###  LEONARD MD WA BOT
   

 <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F33A6A&lines=𝐖𝐞𝐥𝐜𝐨𝐦𝐞+𝐓𝐨+𝐋𝐄𝐎𝐍𝐀𝐑𝐃+𝐌𝐃+𝐁𝐎𝐓.;𝙿𝙾𝚆𝙴𝚁𝙳+𝙱𝚈:+𝐌𝐑+𝐋𝐄𝐎𝐍𝐀𝐑𝐃+𝐓𝐄𝐂𝐇;𝐜𝐫𝐞𝐚𝐭𝐞𝐝+𝐛𝐲:+𝐋𝐄𝐎𝐍𝐀𝐑𝐃+𝐌𝐃;𝐌𝐑:+𝐓𝐄𝐂𝐇𝐍𝐎𝐋𝐎𝐆𝐘+🥷;𝐧𝐞𝐰+𝐯𝐢𝐫𝐬𝐢𝐨𝐧+💥;2024+-+2025.&heart;++;Self-taught+Back-Created+By,;Ibrahim+Adams+Am+The,;Best+Is+Bot+For+You+To,;Deploy..<3"></a>
 <a href="https://files.catbox.moe/vmibx0.jpg">
 <img alt="LEONARD-MD" height="300" src="https://files.catbox.moe/vmibx0.jpg">

## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F33A6A&lines=𝐖𝐞𝐥𝐜𝐨𝐦𝐞+𝐓𝐨+𝐋𝐄𝐎𝐍𝐀𝐑𝐃+𝐌𝐃+𝐁𝐎𝐓.;𝙿𝙾𝚆𝙴𝚁𝙳+𝙱𝚈:+𝐌𝐑+𝐋𝐄𝐎𝐍𝐀𝐑𝐃+𝐓𝐄𝐂𝐇;𝐜𝐫𝐞𝐚𝐭𝐞𝐝+𝐛𝐲:+𝐋𝐄𝐎𝐍𝐀𝐑𝐃+𝐌𝐃;𝐌𝐑:+𝐓𝐄𝐂𝐇𝐍𝐎𝐋𝐎𝐆𝐘+🥷;𝐧𝐞𝐰+𝐯𝐞𝐫𝐬𝐢𝐨𝐧+💥;2024+-+2025.)](https://git.io/typing-svg)



  </h1> 
<p align="center">l introduce <b>LEONARD-MD</b>, a powerful simple WhatsApp bot </p>

</p>
  <p align="center">
<a href="https://github.com/leonard1tech?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Leonard1tech?label=Followers&style=social"></a>
<a href="https://github.com/leonard1tech/leonard-md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/Leonard1tech/leonard-md?&style=social"></a>
<a href="https://github.com/Leonard1tech/leonard-md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/leonard1tech/leonard-md?style=social"></a>
<a href="https://github.com/leonard1tech/leonard-md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/leonard1tech/leonard-md?label=Watching&style=social"></a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{leonard1tech}/count.svg" alt="leonard-md :: Visitor's Count"/></p>

---


</a>
  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&black=true&scan=true" alt="Widget with the current Spotify song"  />
</div>

---

<p align="center">
  <a href="https://github.com/leonard1tech/Leonard-md"><b>Leonard-md</b></a> Support Deploy On...
</p>

<p align="center">
  <a href="https://github.com/leonard1tech/Leonard-Md/blob/main/temp/deploy-on-vps.md"><img src="https://img.shields.io/badge/self hosting-3d1513?style=for-the-badge&logo=serverless&logoColor=FD5750"></a>
  <a href="https://dashboard.heroku.com/new?template=https://github.com/leonard1tech/LEONARD-MD/tree/main"><img src="https://img.shields.io/badge/heroku-9d7acc?style=for-the-badge&logo=heroku&logoColor=430098"></a>
  <a href="https://whatsapp.com/channel/0029VakLfckBlHpYVxryFJ14"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>



    
 
 



---





## HOW TO DEPLOY LEONARD MD



## 1.FIRST STEP 
## Fork Leonard Md Repo
👇 👇  👇 👇
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+ℙ𝕃𝔼𝔸𝕊𝔼+𝔽𝕆ℝ𝕂+𝕋ℍ𝔼+ℝ𝔼ℙ𝕆)](https://git.io/typing-svg)
 
- <a href="https://github.com/leonard1tech/LEONARD-MD/fork"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/FORK THIS REPO-h?color=darkblue&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

star✨ my repo if you like this bot🤖


## 2.SECOND STEP 


 GET SESSION ID BY



[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+𝕋ℍ𝕀𝕊+𝕀𝕊+𝕊𝔼𝕊𝕊𝕀𝕆ℕ+𝕊𝔼𝕋𝔼😎)](https://git.io/typing-svg)


### QR SITE



- <a href="https://Leonard-session.onrender.com/wasiqr"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/QR CODE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

### SESSION SITE


- <a href="https://leonard-session-496x.onrender.com"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/PAIRING CODE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>





### 3.THIRD STEP 
1. If You Don't Have An Account On Heroku**



   <br>
    <a 
- <a align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-darkblue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

### 2. If You Have Account On Heroku**👇 👇 👇

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+100%+𝗦𝗔𝗙𝗘+𝗢𝗡+𝗛𝗘𝗥𝗢𝗞𝗨)](https://git.io/typing-svg)
 


   <br>
    - <a href='https://dashboard.heroku.com/new?template=https://github.com/leonard1tech/LEONARD-MD/tree/main' target="_darkblue"><img alt='DEPLOY TO HEROKU' src="https://img.shields.io/badge/Deploy%20To%20Heroku-darkblue?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>


### DEPLOY ON RENDER

1. If you don't have an account in RENDER, create one and deploy.



   <br>
    <a href='https://dashboard.render.com/select-repo?type=web' target="_darkblue"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-red?style=for-the-badge&logo=render&logoColor=white'/></a>




   ###

CONTACT DEVELOPER ON WHATSAPP 

<a href="https://wa.me/message/255757103671" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/leonard tech contact -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


  
 
<a href="https://whatsapp.com/channel/0029VakLfckBlHpYVxryFJ14" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ LEONARD_TECH  CHANNEL -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />





  ## License

The WhatsApp Bot LEONARD MD is released under the [MIT License](https://opensource.org/licenses/MIT).

 <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+•Role+number-one; don't-trust+any one+🖐️😊;DEVELOPED+BY+LEONARD+TECH;RELEASED+DATE+01%2F10%2F2024." alt="Typing SVG" /></a>


🌟 𝕋ℍ𝔸ℕ𝕂 𝕐𝕆𝕌 𝔽𝕆ℝ ℂℍ𝕆𝕆𝕊𝕀ℕ𝔾 LEONARD🍀_MD 🌟

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&random=false&width=435&lines=THIS+IS+LEONARD- MD+MADE+IN+TANZANIA+🇹🇿♥️" alt="Typing SVG" /></a>

## 𝔻𝔼𝕍𝔼𝕃𝕆ℙ𝔼ℝ𝕊 :

- [**LEONARD TECH**](http://github.com/zedkazzozoranda091)

★im born to win😎. ©
     

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=700&size=33&pause=1000&color=5513F7&width=435&lines=keep+using+LEONARD+MD😊" alt="Typing SVG" /></a>





*KINGDOM*

<table>
  <tr>
    <td>𝑲𝒊𝒏𝒈 𝑳𝒆𝒐𝒏𝒂𝒓𝒅👑</td></td>
    <td>𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑪𝒉𝒂𝒏𝒏𝒆𝒍</td>
  </tr>
  <tr>
    <td><a href="https://wa.me/255757103671?"><img src="https://files.catbox.moe/1opvdg.jpg" width="180"</td>
    <td><a href="https://whatsapp.com/channel/0029VakLfckBlHpYVxryFJ14"><img src="https://files.catbox.moe/38ofr2.jpg" width="180"</td>
  </tr>
</table>

</p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


     
